# app.py
import os
import threading
import queue
import uuid
import time
from flask import Flask, render_template, request, jsonify, send_from_directory
from yt_dlp import YoutubeDL

app = Flask(__name__, template_folder="templates", static_folder="static")

BASE_DIR = os.path.dirname(__file__)
DOWNLOAD_DIR = os.path.join(BASE_DIR, "downloads")
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

# In-memory task store
tasks = {}          # task_id -> task dict
task_queue = queue.Queue()

# Worker thread processes tasks serially
def worker():
    while True:
        task_id = task_queue.get()
        if task_id is None:
            break
        task = tasks.get(task_id)
        if not task:
            task_queue.task_done()
            continue
        try:
            task['status'] = 'processing'
            if task['mode'] == 'single':
                _download_single(task_id, task)
            elif task['mode'] == 'playlist':
                _download_playlist(task_id, task)
            task['status'] = 'done'
        except Exception as e:
            task['status'] = 'error'
            task['error'] = str(e)
        finally:
            task_queue.task_done()

worker_thread = threading.Thread(target=worker, daemon=True)
worker_thread.start()

# Generic progress hook factory
def make_progress_hook(task_id):
    def progress_hook(d):
        t = tasks.get(task_id)
        if not t:
            return

        status = d.get('status')
        info = d.get('info_dict') or {}
        # playlist_index may appear in info or as a top-level key
        p_idx = info.get('playlist_index') or d.get('playlist_index') or info.get('playlist_index')
        p_total = info.get('playlist_count') or d.get('playlist_count') or None

        if status == 'downloading':
            percent = d.get('percent')
            t['progress'] = {
                'status': 'downloading',
                'percent': round(percent, 2) if percent is not None else None,
                'speed': d.get('speed'),
                'eta': d.get('eta'),
                'filename': d.get('filename'),
                'item': p_idx,
                'of': p_total
            }
        elif status == 'finished':
            fn = d.get('filename')
            # append file name to tasks
            if fn:
                t.setdefault('files', []).append(os.path.basename(fn))
            t['progress'] = {
                'status': 'finished',
                'filename': fn,
                'item': p_idx,
                'of': p_total
            }
        elif status == 'error':
            t['progress'] = {'status': 'error', 'info': d}
    return progress_hook

# Single video download
def _download_single(task_id, task):
    url = task['url']
    choice = task.get('choice', 'best')
    force_h264 = bool(task.get('force_h264', False))
    audio_format = task.get('audio_format', 'mp3')

    outtmpl = os.path.join(DOWNLOAD_DIR, '%(title)s [%(id)s].%(ext)s')

    ydl_opts = {
        'outtmpl': outtmpl,
        'noplaylist': True,
        'progress_hooks': [make_progress_hook(task_id)],
        'writesubtitles': False,
        'quiet': True,
        'no_warnings': True,
        # keep temporary fragments visible if needed
    }

    # Audio-only
    if choice == 'audio':
        ydl_opts.update({
            'format': 'bestaudio/best',
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': audio_format,
                'preferredquality': '192',
            }],
            # prefer mp3/m4a output depending on selected codec handled by postprocessor
        })
    else:
        # pick format string from quality choice. Support 2160 (4k), 1440, 1080 etc.
        if choice == 'best':
            fmt = 'bestvideo+bestaudio/best'
        else:
            # numeric heights
            try:
                h = int(choice)
                fmt = f'bestvideo[height<={h}]+bestaudio/best'
            except Exception:
                fmt = 'bestvideo+bestaudio/best'
        ydl_opts['format'] = fmt
        # If user requested re-encode to H.264, request postprocessor args to force libx264 + aac
        if force_h264:
            # We ask yt-dlp to convert/merge to mp4 and pass FFmpeg args for re-encoding
            ydl_opts['merge_output_format'] = 'mp4'
            # 'postprocessor_args' will be passed to ffmpeg when merging/converting
            # These arguments ensure libx264 + aac with reasonable default CRF/preset
            ydl_opts['postprocessor_args'] = [
                '-c:v', 'libx264',
                '-preset', 'fast',
                '-crf', '23',
                '-c:a', 'aac',
                '-b:a', '192k'
            ]
            # ensure FFmpegVideoConvertor is used when necessary
            ydl_opts['postprocessors'] = [
                {'key': 'FFmpegVideoConvertor', 'preferredformat': 'mp4'}
            ]
        else:
            # prefer mp4 container when merging if possible (makes Premiere happy for many sources)
            ydl_opts['merge_output_format'] = 'mp4'

    with YoutubeDL(ydl_opts) as ydl:
        ydl.download([url])

# Playlist download (serial, with numeric prefixes)
def _download_playlist(task_id, task):
    url = task['url']
    choice = task.get('choice', 'best')
    force_h264 = bool(task.get('force_h264', False))
    audio_format = task.get('audio_format', 'mp3')

    # outtmpl includes zero-padded playlist_index (03d)
    outtmpl = os.path.join(DOWNLOAD_DIR, '%(playlist_index)03d - %(title)s [%(id)s].%(ext)s')

    # Base playlist options (let yt-dlp handle playlist ordering & naming)
    ydl_opts = {
        'outtmpl': outtmpl,
        'noplaylist': False,      # allow playlist download
        'progress_hooks': [make_progress_hook(task_id)],
        'writesubtitles': False,
        'quiet': True,
        'no_warnings': True,
        # ensure yt-dlp does not skip items unless user requested
    }

    # Format selection (same logic as single)
    if choice == 'audio':
        ydl_opts.update({
            'format': 'bestaudio/best',
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': audio_format,
                'preferredquality': '192',
            }],
        })
    else:
        if choice == 'best':
            fmt = 'bestvideo+bestaudio/best'
        else:
            try:
                h = int(choice)
                fmt = f'bestvideo[height<={h}]+bestaudio/best'
            except:
                fmt = 'bestvideo+bestaudio/best'
        ydl_opts['format'] = fmt
        ydl_opts['merge_output_format'] = 'mp4'

        if force_h264:
            ydl_opts['postprocessor_args'] = [
                '-c:v', 'libx264',
                '-preset', 'fast',
                '-crf', '23',
                '-c:a', 'aac',
                '-b:a', '192k'
            ]
            ydl_opts['postprocessors'] = [
                {'key': 'FFmpegVideoConvertor', 'preferredformat': 'mp4'}
            ]

    # Let yt-dlp download the whole playlist sequentially (it preserves playlist_index)
    with YoutubeDL(ydl_opts) as ydl:
        ydl.download([url])

# Routes
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/start_download", methods=["POST"])
def start_download():
    data = request.json or {}
    url = (data.get("url") or "").strip()
    mode = data.get("mode", "single")
    choice = data.get("choice", "best")
    audio_format = data.get("audio_format", "mp3")
    force_h264 = bool(data.get("force_h264", False))

    if not url:
        return jsonify({"error": "No URL provided"}), 400

    task_id = str(uuid.uuid4())
    task = {
        'id': task_id,
        'url': url,
        'mode': mode,
        'choice': choice,
        'audio_format': audio_format,
        'force_h264': force_h264,
        'status': 'queued',
        'progress': {'status': 'queued'},
        'files': []
    }
    tasks[task_id] = task
    task_queue.put(task_id)
    return jsonify({"task_id": task_id}), 200

@app.route("/task_status/<task_id>")
def task_status(task_id):
    t = tasks.get(task_id)
    if not t:
        return jsonify({"error": "task not found"}), 404
    return jsonify({
        'id': t['id'],
        'status': t.get('status'),
        'progress': t.get('progress'),
        'files': t.get('files'),
        'error': t.get('error')
    })

@app.route("/downloads/<path:filename>")
def download_file(filename):
    return send_from_directory(DOWNLOAD_DIR, filename, as_attachment=True)

@app.route("/list_downloads")
def list_downloads():
    files = []
    for f in sorted(os.listdir(DOWNLOAD_DIR)):
        files.append(f)
    return jsonify({'files': files})

if __name__ == "__main__":
    # Note: for production use a proper WSGI server and persistent task queue.
    app.run(debug=True, port=5000)
